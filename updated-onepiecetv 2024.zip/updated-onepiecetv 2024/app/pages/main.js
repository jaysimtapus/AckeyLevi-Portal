define([
  'app/pages/insert-coin/InsertCoinPage',
  'app/pages/home/HomePage',
  'app/pages/select-coinslot/SelectCoinslotPage.js',
  'app/pages/buy-eload/BuyEloadPage.js',
  'app/pages/buy-wifi-buttons/BuyWifiButtonsComponent',
  'app/pages/more-buttons/MoreButtons',
  'app/pages/receipt-page/ReceiptPage',
  'app/pages/view-vouchers/ViewVouchers',
  'app/pages/view-rates/ViewRates',
  'app/pages/gcash-cashin/GcashCashin',
  'app/pages/more-features/more-features',
  'app/pages/tutorial/tutorial',
  'app/pages/view-account/ViewAccount'
], function() {});
