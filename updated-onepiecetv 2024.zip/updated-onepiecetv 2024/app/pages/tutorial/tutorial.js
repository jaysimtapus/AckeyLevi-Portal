define([
  'knockout',
  'rootVM',
  'app/services/config',
  'app/observables/customer'
], function(ko, rootVM, config, customer) {
  ko.components.register('tutorial', {
    viewModel: function () {
      this.config = config;
      this.customer = customer;

      this.koDescendantsComplete = function () {
        rootVM.showingStatusNav(false);
        rootVM.showingBanners(true);
        rootVM.showingSessionsTable(false);
        customer.fetch(function () {});
      };
    },
    template: {require: 'text!app/pages/tutorial/tutorial.html'}
  });
});
